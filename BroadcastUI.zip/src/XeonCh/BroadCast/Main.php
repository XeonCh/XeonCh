<?php

namespace XeonCh\BroadCast;

use pocketmine\Server;
use pocketmine\Player;

use pocketmine\plugin\PluginBase as Base;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;

use pocketmine\event\Listener;
use jojoe77777\FormApi;

class Main extends Base implements Listener{

    public function onEnable(){

    }

    public function onCommand(CommandSender $sender, Command $cmd, String $label, Array $args) : bool {

        switch($cmd->getName()){
            case "bc":
             if($sender->hasPermission("bc.use")){
                 if($sender instanceof Player){
                     $this->bc($sender);
                 }
             } else {
                 $sender->sendMessage("§cYou dont have permission to use this command");
             }
        }
    return true;
    }

    public function bc($player){
        $api = $this->getServer()->getPluginManager()->getPlugin("FormAPI");
        $form = $api->createCustomForm(function (Player $player, array $data = null){
            if($data === null){
                return true;
            }
            if($data[0] == null){
                $player->sendMessage("§bYou need to type a message!");
                return true;
            }
            if($data[1] == true){
                $this->getServer()->broadcastMessage("§7[§eBroadcast§7] §a$data[0]");
                return true;
            }
            if($data[2] == true){
                $this->getServer()->broadcastMessage("§7[§eBroadcast§7] §c$data[0]");
                return true;
            }
            if($data[3] == true){
                $this->getServer()->broadcastMessage("§7[§eBroadcast§7] §e$data[0]");
                return true;
            }
            if($data[4] == true){
                $this->getServer()->broadcastMessage("§7[§eBroadcast§7] §b$data[0]");
                return true;
            }
            if($data[5] == true){
                $this->getServer()->broadcastMessage("§7[§eBroadcast§7] §d$data[0]");
                return true;
            }
            if($data[6] == true){
				$this->getServer()->broadcastMessage("§7[§eBroadcast§7] §f$data[0]");
				return true;
			}
			if($data[7] == true){
				$this->getServer()->broadcastMessage("§7[§eBroadcast§7] §6$data[0]");
				return true;
			}
			if($data[8] == true){
				$this->getServer()->broadcastMessage("§7[§eBroadcast§7] §9$data[0]");
				return true;
			}
            $this->getServer()->broadcastMessage("§7[§eBroadcast§7] $data[0]");
        });
        $form->setTitle("§eBroadCast §gUI");
        $form->addInput("§fType a message you want to sent to all players!");
        $form->addToggle("§aGreen", false);
        $form->addToggle("§cRed", false);
        $form->addToggle("§eYellow", false);
        $form->addToggle("§bAqua", false);
        $form->addToggle("§dPurple", false);
        $form->addToggle("§fWhite", false);
        $form->addToggle("§6Gold", false);
        $form->addToggle("§9Blue", false);
        $form->sendToPlayer($player);
        return $form;
    }

}